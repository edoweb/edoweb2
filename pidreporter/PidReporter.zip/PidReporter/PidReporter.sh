#Author: Jan Schnasse
#Sprache: Java
#Ort: urania.hbz-nrw.de:/hbz/proc/schnasse/edoweb/PIDReporter
#Logs: PIDReporter.log*
#Config: pidreporter.properties
#Timestamp: .oaitimestamp
#Aufruf: java -jar pidreporter.jar pidreporter.properties
#Aufruf: ./PIDReporter.sh
#
#
#Konfiguration:
# pidreporter.properties
#
#Weiteres siehe: https://wiki.hbz-nrw.de/display/EDO/PIDReporter
#
java -jar pidreporter.jar pidreporter.properties
